<?php

	$con = mysqli_connect('localhost','id13928762_nitc','San123@000webhost','id13928762_mydb'); // tododb onlinehealthcenter

	if($con == false){
		echo "Connection is not done";
	}
	//INSERT INTO staff (`s_id` , `name` , `mobile` , `address` , `img` , `adhar` , `jdate` , `email` , `pass`) VALUES ('staff' ,'staff' , '7277118639' , '1234' , 'photo.png' , '123456' , '2020-12-12' , 'staff@gmail.com' , '1234');

?>


